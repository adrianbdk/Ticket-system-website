<?php
include "baza.php";

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<link  rel="stylesheet" href="css\style.css">
</head>
<body>
<?php
include "menu.php";
?>
<div align="center">
<form method="POST" action="nazwaalbumu.php">
<b>Podaj nazwę albumu: <input type="text" name="nazwaalbumu"></b>

<input type="submit" value="Zarejestruj" name="rejestruj">
<div class='odp'>
<?php

if(isset($_SESSION['nazwa']))
{
	echo $_SESSION['nazwa'];
	echo "<br>";
}
unset ($_SESSION['nazwa']);
?>
</div>

	<div class="footer">Adrian Budka 4Tb</div>
</div>
</body>
</html>