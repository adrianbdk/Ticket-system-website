﻿<!DOCTYPE html>
<html>
<head>
		
		
	<meta charset="UTF-8">
	<link rel="Stylesheet" type="text/css" href="css/style.css" />
		<title>Rejestracja</title>
	</head>
<body>
	
	<?php
	session_start();
	require("baza.php");
	$link = connectWithDatabase();
			
	
		if (strlen($_POST['haslo']) < 6)
		{$_SESSION['warning'];
		header("Location:index.php?error=dlugosc");
		exit;}
		
		elseif (strlen($_POST['haslo']) > 20)
		{$_SESSION['warning'];
		header("Location:index.php?error=dlugosc2");
		exit;}

		
		if (!preg_match("/^[0-9A-Z_]+$/i", $_POST['login']))
		{$_SESSION['warning'];
		header("Location:index.php?error=znak");
		exit;}

print_r($link);		
	$query="SELECT login FROM użytkownicy";
	$result = mysqli_query($link, $query);
	while($row = $result->fetch_assoc())
		if ($_POST['login'] == $row['login'])
			$_SESSION['uzytkownik'] = true;


		if (!preg_match("/[A-Z]/",$_POST['haslo']))
		{$_SESSION['warning'];
		header("Location:index.php?error=wielka");
		exit;}
		
		elseif (!preg_match("/[a-z]/",$_POST['haslo']))
		{$_SESSION['warning'];
		header("Location:index.php?error=mala");
		exit;}
		
		elseif (!preg_match("/[0-9]/",$_POST['haslo']))
		{$_SESSION['warning'];
		header("Location:index.php?error=cyfra");
		exit; }

		elseif ($_POST['haslo']!=$_POST['haslo'])
		{$_SESSION['warning'];
		header("Location:index.php?error=hasla");
		exit; }
		
		else
		{	$login = $_POST['login'];
		$haslo = md5($_POST['haslo']);
		$email = $_POST['email'];
		$date_user = date("Y-m-d");
		$query="INSERT INTO użytkownicy SET login='$login', haslo='$haslo', email='$email', zarejestrowany='$date_user', uprawnienia='użytkownik', aktywny=1";
		$result = mysqli_query($link, $query);
		$_SESSION['login'] = $login;
		$_SESSION['email'] = $email;
		$_SESSION['uprawnienia'] = "użytkownik";
		$_SESSION['aktywny'] = 1;
		$_SESSION['logowanie'] = 1;
		$_SESSION['id'] = $link->insert_id;
					$query = "SELECT * FROM użytkownicy WHERE login = '$_SESSION[login]'";
			$result = mysqli_query($link, $query);
			$user = mysqli_fetch_assoc($result);
		
			mysqli_close($link);
		
			$_SESSION["current_user"] = $user;
		header("Location: rejestracja-ok.php");
			
		exit;
		}
?>
	
	
	<div class="footer">Adrian Budka 4Tb</div>
</body>
</html>