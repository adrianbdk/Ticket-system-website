<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<link rel="Stylesheet" type="text/css" href="css/style.css" />
		<title>Logowanie</title>
	</head>
<body>
	<h2>Sprawdzanie</h2>
	<?php
	session_start();
	require("baza.php");
	$link = connectWithDatabase();
	$_SESSION['login'] = $_POST['login'];
		
	$query="SELECT * FROM użytkownicy WHERE login='".$_POST['login']."'";
	$result = mysqli_query($link, $query);
	if ($result->num_rows > 0) {
		$row = $result->fetch_assoc();
		if (md5($_POST['haslo']) == $row['haslo']) {
			$_SESSION['id'] = $row['id'];
			$_SESSION['login'] = $row['login'];
			$_SESSION['email'] = $row['email'];
			$_SESSION['aktywny'] = $row['aktywny'];
			$_SESSION['uprawnienia'] = $row['uprawnienia'];
			

			

			$query = "SELECT * FROM użytkownicy WHERE login = '$_SESSION[login]'";
			$result = mysqli_query($link, $query);
			$user = mysqli_fetch_assoc($result);
		
			mysqli_close($link);
		
			$_SESSION["current_user"] = $user;
			
		if ($row['aktywny'] == 0)
		{$_SESSION['warning'];	
		header("Location:index.php?error=nieaktywny");
		exit;}
		
		else
		{header("Location: galeria.php");	
		$_SESSION['zalogowanie'] = 1; 
		exit;}}
		
		else 
		{$_SESSION['warning'];	
		header("Location:index.php?error=zlehaslo"); 
		exit;}}
		
		else
		{$_SESSION['warning'];	
		header("Location:index.php?error=zlylogin");
		exit;}
		?>
</body>
</html>