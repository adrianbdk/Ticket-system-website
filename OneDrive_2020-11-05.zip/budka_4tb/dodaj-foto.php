<?php
require "baza.php";
$link = connectWithDatabase();

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<link  rel="stylesheet" href="css\style.css">
</head>
<body>
<div align="center">
<?php
include "menu.php";
?>

<form method="POST" action="dodawanie-foto.php" enctype="multipart/form-data">
	<h1>Dodaj zdjęcie</h1><br>
	Wybierz zdjęcie: <input name="file" type="file" required><br>
	Opis zdjęcia: <input nam="opis" type="text"><br>
	<button class="button1" type="submit">Dodaj zdjęcie</button>


</fieldset>
</div>
<div class="footer">Adrian Budka 4Tb</div>
</body>
</html>	