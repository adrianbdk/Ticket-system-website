<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Menu</title>
		<link rel="Stylesheet" type="text/css" href="css/style.css" />
	</head>
<body>
<?php session_start(); ?>


<!--
<div class='topnav'><a href="galeria.php">Galeria</a>
<a href="dodaj-album.php">Załóż album</a>
<a href="dodaj-foto.php">Dodaj zdjęcie</a>
<a href="top-foto.php">Najlepiej oceniane</a>
<a href="nowe-foto.php">Najnowsze</a>
-->
<div id="tabs24"> 
	<ul>
		<li><a href="galeria.php" title="css menus"><span>Galeria</span></a></li>
		<li><a href="dodaj-album.php" title="css menus"><span>Załóż album</span></a></li>
		<li><a href="dodaj-foto.php" title="css menus"><span>Dodaj zdjęcie</span></a></li>
		<li><a href="top-foto.php" title="css menus"><span>Najlepiej ocenian</span></a></li>
		<li><a href="nowe-foto.php" title="css menus"><span>Najnowsze</span></a></li>
	
<?php



if ($_SESSION["zalogowany"]=1) echo '<li><a href="konto.php">Moje konto</a></li>';
if ($_SESSION["zalogowany"]=0) echo '<li><a href="index.php">Zaloguj się</a></li>';
if ($_SESSION["zalogowany"]=0) echo '<li><a href="index.php">Rejestracja</a></li>';
if ($_SESSION["zalogowany"]=1) echo '<li><a href="index.php?logout=true">Wyloguj się</a></li>';
if ($_SESSION['uprawnienia']=="moderator" || $_SESSION['uprawnienia']=="administrator") echo '<a href="admin\index.php">Panel administracyjny</a>';




?>

	</ul>
</div>
</body>
</html>