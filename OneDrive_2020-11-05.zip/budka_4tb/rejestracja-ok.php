﻿<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<link rel="Stylesheet" type="text/css" href="css/style.css" />

		<title>REJESTRACJA UDANA</title>
		
	</head>
<body>
<?php 
	session_start(); $_SESSION['zalogowanie'] = 1;
?>
<strong>UDAŁO SIĘ ZAREJESTROWAĆ!</strong>
<a href="galeria.php" role="button" >Przejdź do galerii</a>
	<div class="footer">Adrian Budka 4Tb</div>
</body>
</html>