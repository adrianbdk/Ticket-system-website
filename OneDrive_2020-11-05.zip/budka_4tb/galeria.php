﻿<!DOCTYPE html>
<html>
<head>


</head>
		<meta charset="UTF-8">
		<link rel="Stylesheet" type="text/css" href="css/style.css" />
		<title>GALERIA</title>

<body>
<div>
<?php

include "menu.php";
?>
</div>
<div align="center">
<?php

    require("baza.php");
    $link = connectWithDatabase();
    
    $query = "SELECT COUNT(*) FROM albumy";
    $result = mysqli_query($link, $query);
    $records = $result->fetch_assoc()['COUNT(*)'];
    $rowsperpage = 20;
    $totalpages = ceil($records / $rowsperpage);

    if (isset($_GET['page']) && is_numeric($_GET['page'])) {
       $page = (int) $_GET['page'];
    } else {
        $page = 1;
    }

    $offset = ($page - 1) * $rowsperpage;

    $query = "SELECT * FROM albumy LEFT JOIN zdjecia ON albumy.id = zdjecia.id_albumu WHERE zdjecia.zaakceptowane = 1 GROUP BY albumy.id LIMIT $offset, $rowsperpage";
    $result = mysqli_query($link, $query);
    while ($row = mysqli_fetch_assoc($result)) {
        $album_id = $row['id_albumu'];
        $query = "SELECT * FROM zdjecia WHERE id_albumu = $album_id AND zaakceptowane = 1 LIMIT 1";
        $sub_result = mysqli_query($link, $query);
        $photo = mysqli_fetch_assoc($sub_result);
        
        $photo_path = "img/" . $album_id . "/" . $photo['id'];
       echo "<a href='album.php?id=".$row['id_albumu']."'><img height=180 width=180 src='" . $photo_path . ".jpg' title='Tytuł galerii: ".$row['tytul']." Utworzono: ".$row['data']."'></a>" . "<br>"; 
     }

     $range = 3;
     
     if ($page > 1) {
        echo " <a href='{$_SERVER['PHP_SELF']}?page=1'><<</a> ";
        $prevpage = $page - 1;
        echo " <a href='{$_SERVER['PHP_SELF']}?page=$prevpage'><</a> ";
     }
     
     for ($x = ($page - $range); $x < (($page + $range) + 1); $x++) {
        if (($x > 0) && ($x <= $totalpages)) {
           if ($x == $page) {
              echo " [<b>$x</b>] ";
           } else {
              echo " <a href='{$_SERVER['PHP_SELF']}?page=$x'>$x</a> ";
           }
        }
     }
                      
     if ($page != $totalpages) {
        $nextpage = $page + 1;
        echo " <a href='{$_SERVER['PHP_SELF']}?page=$nextpage'>></a> ";
        echo " <a href='{$_SERVER['PHP_SELF']}?page=$totalpages'>>></a> ";
     }
	
  
    if (isset($_SESSION["zalogowanie"])) {
        echo "Login: ".$_SESSION['login']."<br>";
        echo "Email: ".$_SESSION['email']."<br>";
        echo "Aktywny: ".$_SESSION['aktywny']."<br>";
        echo "Uprawnienia: ".$_SESSION['uprawnienia']."<br>";
        //echo "<a href='index.php?logout=true'>Wyloguj</a>";
		//echo "<img src=\"obrazek.gif\" border=\"3\" width=\"200\" height=\"200\" style=\"float: right\" >";
    }
	

?>
</div>
	<div class="footer">Adrian Budka 4Tb</div>
</body>
</html>