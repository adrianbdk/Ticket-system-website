<?php
session_start();
require ("baza.php");
$link = connectWithDatabase();
$date = date("Y-m-d-h-i");
$bar = trim($_POST['tytul']);


$znazwa = trim($_POST['nazwaalbumu']);


$nazwaaaa = strlen($_POST['nazwaalbumu']);
if(isset($_POST['nazwaalbumu']))
{
if ($nazwaaaa > 100 || $nazwaaaa < 3)
	{
		$_SESSION['nazwa']="Nazwa albumu jest niewłaściwej długości (od 3 do 100 znaków)";
	}

if (!isset($_SESSION['nazwa']))
{	$date = date('Y-m-d H:i:s');
	//mysqli_query($link, "INSERT INTO albumy (tytul, data, id_uzytkownika) VALUES ('$znazwa' , '$date', '$_SESSION[id]')");
	$query="INSERT INTO albumy SET tytul='$znazwa', data='$date', id_uzytkownika='$_SESSION[id]'";
		$result = mysqli_query($link, $query);
	
	$mkdir = mysqli_insert_id($link);
	$_SESSION['mkdir'] = $mkdir;
	mkdir("img/$mkdir", 0700);
	header ('Location: dodaj-foto.php');
} else header ('Location: dodaj-album.php');
}
?>