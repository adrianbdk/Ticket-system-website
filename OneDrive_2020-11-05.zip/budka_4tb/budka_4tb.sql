-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Czas generowania: 14 Gru 2017, 20:06
-- Wersja serwera: 10.1.26-MariaDB
-- Wersja PHP: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Baza danych: `budka_4tb`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `albumy`
--

CREATE TABLE `albumy` (
  `id` int(11) NOT NULL,
  `tytul` varchar(100) COLLATE utf8_polish_ci NOT NULL,
  `data` datetime NOT NULL,
  `id_uzytkownika` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Zrzut danych tabeli `albumy`
--

INSERT INTO `albumy` (`id`, `tytul`, `data`, `id_uzytkownika`) VALUES
(19, 'album', '2017-12-14 19:22:38', 16);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `użytkownicy`
--

CREATE TABLE `użytkownicy` (
  `id` int(11) NOT NULL,
  `login` varchar(20) COLLATE utf8_polish_ci NOT NULL,
  `haslo` varchar(32) COLLATE utf8_polish_ci NOT NULL,
  `email` varchar(128) COLLATE utf8_polish_ci NOT NULL,
  `zarejestrowany` date NOT NULL,
  `uprawnienia` enum('użytkownik','moderator','administrator') COLLATE utf8_polish_ci NOT NULL,
  `aktywny` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Zrzut danych tabeli `użytkownicy`
--

INSERT INTO `użytkownicy` (`id`, `login`, `haslo`, `email`, `zarejestrowany`, `uprawnienia`, `aktywny`) VALUES
(16, 'uzytkownik1', 'da0e9e09f0321c93cdcc5611b9d15319', 'uzytkownik@gmail.com', '2017-12-14', 'użytkownik', 1),
(17, 'uzytkownik2', 'c91743ae262761624a3731812c52d339', 'uzytkownik2@gmail.com', '2017-12-14', 'użytkownik', 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `zdjecia`
--

CREATE TABLE `zdjecia` (
  `id` int(11) NOT NULL,
  `opis` varchar(255) COLLATE utf8_polish_ci NOT NULL,
  `id_albumu` int(11) NOT NULL,
  `data` datetime NOT NULL,
  `zaakceptowane` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Zrzut danych tabeli `zdjecia`
--

INSERT INTO `zdjecia` (`id`, `opis`, `id_albumu`, `data`, `zaakceptowane`) VALUES
(13, '', 19, '2017-12-14 19:22:52', 1),
(14, '', 19, '2017-12-14 19:23:22', 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `zdjecia_komentarze`
--

CREATE TABLE `zdjecia_komentarze` (
  `id_zdjecia` int(11) NOT NULL,
  `id_użytkownika` int(11) NOT NULL,
  `data` datetime NOT NULL,
  `komentarz` text COLLATE utf8_polish_ci NOT NULL,
  `zaakceptowany` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Zrzut danych tabeli `zdjecia_komentarze`
--

INSERT INTO `zdjecia_komentarze` (`id_zdjecia`, `id_użytkownika`, `data`, `komentarz`, `zaakceptowany`) VALUES
(6, 9, '2017-12-14 17:53:12', 'ale śmieszne', 1),
(6, 9, '2017-12-14 17:53:27', 'hahaha', 1),
(6, 9, '2017-12-14 17:55:32', 'hahaha', 1),
(6, 9, '2017-12-14 18:00:53', 'hahaha', 1),
(6, 9, '2017-12-14 18:01:02', 'hahaha', 1),
(6, 9, '2017-12-14 18:01:51', 'hahaha', 1),
(6, 9, '2017-12-14 18:02:34', 'hahaha', 1),
(6, 9, '2017-12-14 18:03:03', 'hahaha', 1),
(6, 9, '2017-12-14 18:03:07', 'hahaha', 1),
(6, 9, '2017-12-14 18:03:24', 'hahaha', 1),
(6, 9, '2017-12-14 18:03:27', 'hahaha', 1),
(6, 9, '2017-12-14 18:03:38', 'hahaha', 1),
(6, 9, '2017-12-14 18:04:53', 'hahaha', 1),
(6, 9, '2017-12-14 18:05:02', 'hahaha', 1),
(6, 9, '2017-12-14 18:05:30', 'hahaha', 1),
(6, 9, '2017-12-14 18:05:32', 'hahaha', 1),
(6, 9, '2017-12-14 18:06:31', 'hahaha', 1),
(6, 9, '2017-12-14 18:07:46', 'hahaha', 1),
(6, 9, '2017-12-14 18:07:49', 'hahaha', 1),
(6, 9, '2017-12-14 18:11:04', 'hahaha', 1),
(6, 9, '2017-12-14 18:11:10', 'hahaha', 1),
(6, 9, '2017-12-14 18:11:13', 'hahaha', 1),
(6, 9, '2017-12-14 18:13:17', 'hahaha', 1),
(6, 9, '2017-12-14 18:14:19', 'hahaha', 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `zdjecia_oceny`
--

CREATE TABLE `zdjecia_oceny` (
  `id_zdjecia` int(11) NOT NULL,
  `id_użytkownika` int(11) NOT NULL,
  `ocena` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Zrzut danych tabeli `zdjecia_oceny`
--

INSERT INTO `zdjecia_oceny` (`id_zdjecia`, `id_użytkownika`, `ocena`) VALUES
(6, 9, 5),
(6, 9, -5),
(6, 9, 5),
(6, 9, 4),
(6, 9, 2),
(6, 9, 2),
(6, 9, 2),
(10, 15, 10);

--
-- Indeksy dla zrzutów tabel
--

--
-- Indexes for table `albumy`
--
ALTER TABLE `albumy`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `użytkownicy`
--
ALTER TABLE `użytkownicy`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zdjecia`
--
ALTER TABLE `zdjecia`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT dla tabeli `albumy`
--
ALTER TABLE `albumy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT dla tabeli `użytkownicy`
--
ALTER TABLE `użytkownicy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT dla tabeli `zdjecia`
--
ALTER TABLE `zdjecia`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
