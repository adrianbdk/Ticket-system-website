<?php

function connectWithDatabase() {
    $link = mysqli_connect("localhost", "root", "", "budka_4tb");
    if (mysqli_connect_errno()) 
    {
        echo "Błąd połączenia nr: " . mysqli_connect_errno();
        echo "Opis błędu: " . mysqli_connect_error();
        exit();
    }
    mysqli_query($link, 'SET NAMES utf8');
	mysqli_query($link, 'SET CHARACTER SET utf8');
    mysqli_query($link, "SET collation_connection = utf8_polish_ci");
    return $link;
}

?>