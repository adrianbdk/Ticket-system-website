<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Rejestracja, logowanie</title>
		<link rel="Stylesheet" type="text/css" href="css/style.css" />
	</head>
<body>
<div class="css" align="center">
	<h1>Logowanie</h1>
			<form method="POST" action="logowanie.php">
			<input type="text" name="login" placeholder="login" required><br>
			<input type="password" name="haslo" placeholder="hasło" required><br>
			<input class="przycisk przycisk1" type="submit" value="Zaloguj się"><br>
			</form>
	<h1>Rejestracja</h1>
			<form method="POST" action="rejestracja.php">
			<input type="text" name="login" id="login" placeholder="login" onblur="fun()" required><br>
			<input type="password" id="pass" name="haslo" placeholder="hasło" required><br>
			<input type="password" id="pass1" name="haslo1" placeholder="powtórz hasło" required><br>
			<input type="email" id="email" name="email" placeholder="e-mail" required><br>
			<input class="przycisk przycisk1" type="submit" value="Zarejestruj się"><br>
			</form>

	<?php
    session_start();

    if (isset($_GET["error"])) {
        switch ($_GET["error"]) {

				
            
            case "dlugosc1":
                echo "Hasło powinno mieć conajmniej 6 znaków!";
                break;
				
			case "dlugosc2":
                echo "Hasło nie może przekroczyć 20 znaków!";
                break;
				
			case "haslo_niezgodne":
                echo "Hasła nie są zgodne!";
                break;
				
			case "nieaktywny":
                echo "Użytkownik jest nieaktywny!";
                break;
				
			case "uzytkownik":
                echo "Istnieje już taki login!";
                break;
				
			case "wielka":
                echo "Hasło musi zawierać jedną wielką literę!";
                break;
				
			case "mala":
                echo "Hasło musi zawierać jedną małą literę!";
                break;
				
			case "cyfra":
                echo "Hasło musi zawierać jedną cyfrę!";
                break;
				
			case "zle_haslo":
                echo "Złe hasło!";
                break;
				
			case "zly_login":
                echo "Użytkownik o podanym loginie nie istnieje!";
                break;
				
			case "znaki":
                echo "Login zawiera niedopuszczalne znaki!";
                break;
        }
    }
		if (isset($_GET["logout"])){
			if ($_GET["logout"] == "true") {
	include 'baza.php';
	session_start();
	print_r($_SESSION["zalogowany"]);
	unset ($_SESSION['login']);
	unset ($_SESSION['haslo']);
	unset ($_SESSION['data']);
	unset ($_SESSION['email']);
	unset ($_SESSION['zalogowany']);
	unset ($_SESSION['id']);
	header ("Location: index.php");

				header("Location:index.php");
        }
    }
?>
			
			

			
	<div class="footer">Adrian Budka 4Tb</div>
</body>
</html>