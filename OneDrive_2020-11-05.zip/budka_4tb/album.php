<?php $page_title = "Album"; ?>
<?php

    if (!isset($_GET['id'])) {
        header("Location:index.php");
        die();
    }

    $current_album_id = $_GET['id'];
?>

<div><?php include "menu.php";?></div>

<div align="center"><a href='galeria.php'><h3>Lista albumów</h3></a></div>

<div align="center">
<?php
    require("baza.php");
    $link = connectWithDatabase();
    $query = "SELECT COUNT(*) FROM zdjecia WHERE id_albumu = $current_album_id";
    $result = mysqli_query($link, $query);
    $records = $result->fetch_assoc()['COUNT(*)'];

    $rowsperpage = 20;

    $totalpages = ceil($records / $rowsperpage);

    if (isset($_GET['page']) && is_numeric($_GET['page'])) {
        $page = (int) $_GET['page'];
    } else {
        $page = 1;
    }

    $offset = ($page - 1) * $rowsperpage;


    $query = "SELECT * FROM zdjecia WHERE id_albumu = $current_album_id AND zaakceptowane = 1 LIMIT $offset, $rowsperpage";
    $result = mysqli_query($link, $query);
    while ($row = mysqli_fetch_assoc($result)) {
       echo "<a href='foto.php?id=".$row['id']."'><img width=180 height=180 src='img/". $current_album_id . "/" . $row['id']. ".jpg'></a>" . "<br>";
    }

    $range = 3;
     
    if ($page > 1) {
       echo " <a href='{$_SERVER['PHP_SELF']}?id=$current_album_id&page=1'><<</a> ";
       $prevpage = $page - 1;
       echo " <a href='{$_SERVER['PHP_SELF']}?id=$current_album_id&page=$prevpage'><</a> ";
    }
     
    for ($x = ($page - $range); $x < (($page + $range) + 1); $x++) {
       if (($x > 0) && ($x <= $totalpages)) {
          if ($x == $page) {
            echo " [<b>$x</b>] ";
          } else {
            echo " <a href='{$_SERVER['PHP_SELF']}?id=$current_album_id&page=$x'>$x</a> ";
           }
        }
    }

    if ($page != $totalpages) {
        $nextpage = $page + 1;
        echo " <a href='{$_SERVER['PHP_SELF']}?id=$current_album_id&page=$nextpage'>></a> ";
        echo " <a href='{$_SERVER['PHP_SELF']}?id=$current_album_id&page=$totalpages'>>></a> ";
    }

    $link = connectWithDatabase();
    $query = "SELECT * FROM albumy WHERE id = $current_album_id";
    $result = mysqli_query($link, $query);
    $album = mysqli_fetch_assoc($result);
    $album_owner_id = $album['id_uzytkownika'];
    if($_SESSION['current_user']['id'] == $album_owner_id) {
        print("<a href='dodaj-foto.php?id=".$current_album_id."'><h3>Dodaj zdjęcie</h3></a>");
    }
	
	 if (isset($_SESSION["zalogowanie"])) {
        echo "Login: ".$_SESSION['login']."<br>";
        echo "Email: ".$_SESSION['email']."<br>";
        echo "Aktywny: ".$_SESSION['aktywny']."<br>";
        echo "Uprawnienia: ".$_SESSION['uprawnienia']."<br>";
        echo "<a href='index.php?logout=true'>Wyloguj</a>";
	 }
	 
?>
</div>
	<div class="footer">Adrian Budka 4Tb</div>

<div align="center"><a href='galeria.php'><h3>Lista albumów</h3></a></div>